package main

import (
	"context"
	"embed"
	"log"

	"github.com/wailsapp/wails/v2"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"

	"my_deepseek/app"
)

//go:embed all:frontend/dist
var assets embed.FS

func main() {
	log.Printf("my_deepseek starting...")
	log.Printf("Target URL: %s", TargetURL)

	application := app.NewApp()

	err := wails.Run(&options.App{
		Title:  title,
		Width:  1400,
		Height: 900,
		AssetServer: &assetserver.Options{
			Assets: assets,
		},
		BackgroundColour:         &options.RGBA{R: 255, G: 255, B: 255, A: 1},
		EnableDefaultContextMenu: true, // 临时开启右键菜单，可通过"检查"打开 DevTools
		OnStartup:                func(ctx context.Context) { application.Startup(ctx, TargetURL) },
		OnDomReady:               application.DomReady,
		OnBeforeClose:            application.OnBeforeClose,
		Bind: []any{
			application,
		},
	})

	if err != nil {
		println("Error:", err.Error())
	}
}
