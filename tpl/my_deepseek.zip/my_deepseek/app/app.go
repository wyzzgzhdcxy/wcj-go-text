package app

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/wailsapp/wails/v2/pkg/runtime"
)

// WindowState 保存窗口状态
type WindowState struct {
	Width  int `json:"width"`
	Height int `json:"height"`
	X      int `json:"x"`
	Y      int `json:"y"`
}

// App struct
type App struct {
	ctx     context.Context
	ipcPort int
}

// NewApp creates a new App application instance
func NewApp() *App {
	return &App{}
}

// getConfigPath 获取配置文件路径
func getConfigPath() (string, error) {
	dir, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, "my_deepseek", "window_state.json"), nil
}

// loadWindowState 加载窗口状态
func loadWindowState() (*WindowState, error) {
	path, err := getConfigPath()
	if err != nil {
		return nil, err
	}

	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var state WindowState
	if err := json.Unmarshal(data, &state); err != nil {
		return nil, err
	}
	return &state, nil
}

// saveWindowState 保存窗口状态
func saveWindowState(state *WindowState) error {
	path, err := getConfigPath()
	if err != nil {
		return err
	}

	// 确保目录存在
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}

	data, err := json.Marshal(state)
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0644)
}

// saveCurrentWindowState 保存当前窗口状态
func (a *App) saveCurrentWindowState() {
	width, height := runtime.WindowGetSize(a.ctx)
	x, y := runtime.WindowGetPosition(a.ctx)

	state := &WindowState{
		Width:  width,
		Height: height,
		X:      x,
		Y:      y,
	}

	if err := saveWindowState(state); err != nil {
		log.Printf("保存窗口状态失败: %v", err)
	} else {
		log.Printf("窗口状态已保存: %dx%d at (%d,%d)", state.Width, state.Height, state.X, state.Y)
	}
}

// startIPCServer 启动本地 HTTP 服务器，供外部页面 JS 通过 fetch 回调 Go
// 127.0.0.1 属于"可信来源"，WebView2 不做混合内容拦截，且 CORS 开放
func (a *App) startIPCServer() {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		log.Printf("IPC server listen failed: %v", err)
		return
	}
	a.ipcPort = listener.Addr().(*net.TCPAddr).Port
	log.Printf("IPC server listening on port %d", a.ipcPort)

	mux := http.NewServeMux()
	mux.HandleFunc("/open-url", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		url := r.URL.Query().Get("url")
		if url != "" && (strings.HasPrefix(url, "http://") || strings.HasPrefix(url, "https://")) {
			log.Printf("Opening in default browser: %s", url)
			runtime.BrowserOpenURL(a.ctx, url)
		}
		w.WriteHeader(http.StatusOK)
	})
	go http.Serve(listener, mux) //nolint:errcheck
}

// Startup is called when the app starts
func (a *App) Startup(ctx context.Context, targetURL string) {
	a.ctx = ctx
	a.startIPCServer()
	log.Printf("my_deepseek startup!")

	// 在 Startup 时跳转到目标 URL（URL 在 main.go 中定义）
	if targetURL != "" {
		js := fmt.Sprintf(`window.location.replace('%s');`, targetURL)
		runtime.WindowExecJS(ctx, js)
		log.Printf("跳转到目标 URL: %s", targetURL)
	}

	// 尝试加载上次的窗口状态
	state, err := loadWindowState()
	if err != nil || state.Width <= 0 || state.Height <= 0 {
		// 没有保存的状态，使用默认值
		screens, err := runtime.ScreenGetAll(ctx)
		if err == nil && len(screens) > 0 {
			screenWidth := screens[0].Size.Width
			screenHeight := screens[0].Size.Height
			log.Printf("屏幕尺寸: %dx%d", screenWidth, screenHeight)

			newWidth := screenWidth - 100
			newHeight := screenHeight - 100
			runtime.WindowSetSize(ctx, newWidth, newHeight)
			runtime.WindowCenter(ctx)
		}
	} else {
		// 使用保存的状态
		log.Printf("恢复窗口尺寸: %dx%d at (%d,%d)", state.Width, state.Height, state.X, state.Y)
		runtime.WindowSetSize(ctx, state.Width, state.Height)
		if state.X > 0 && state.Y > 0 {
			runtime.WindowSetPosition(ctx, state.X, state.Y)
		} else {
			runtime.WindowCenter(ctx)
		}
	}
}

// DomReady is called when the DOM is ready
func (a *App) DomReady(ctx context.Context) {
	log.Printf("DomReady, scheduling link interceptor injection...")
	// DeepSeek 页面通过 window.location.replace 加载，需持续注入直到生效
	// 使用循环注入确保在页面跳转完成后脚本仍然存在
	go func() {
		delays := []time.Duration{1, 2, 3, 5, 8, 12, 20}
		for i, delay := range delays {
			time.Sleep(delay * time.Second)
			log.Printf("第 %d 次注入 link interceptor (延迟 %ds)...", i+1, delay)
			a.injectLinkInterceptor(ctx)
		}
		// 持续定期注入，确保长期有效
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		count := 0
		for range ticker.C {
			count++
			log.Printf("定期注入 link interceptor (第 %d 次)...", count)
			a.injectLinkInterceptor(ctx)
		}
	}()
}

// injectLinkInterceptor 向 WebView 中注入 JS，拦截新窗口/外链，用默认浏览器打开
func (a *App) injectLinkInterceptor(ctx context.Context) {
	js := fmt.Sprintf(`(function() {
	if (window.__deepseekInterceptorActive) return;
	window.__deepseekInterceptorActive = true;

	// window.runtime 在外部页面不可用，改用本地 IPC HTTP 服务器
	function openInBrowser(url) {
		if (!url || (!url.startsWith('http://') && !url.startsWith('https://'))) return;
		fetch('http://127.0.0.1:%d/open-url?url=' + encodeURIComponent(url))
			.catch(function(e) { console.warn('[DeepSeek Wrapper] open-url failed:', e); });
	}

	// 对单个 <a> 元素打补丁：移除 target="_blank" 防止 WebView2 原生拦截，改用 JS 处理
	function patchLink(link) {
		if (link.__wailsPatched) return;
		link.__wailsPatched = true;
		link.removeAttribute('target');
		link.addEventListener('click', function(e) {
			var href = link.href;
			if (!href || (!href.startsWith('http://') && !href.startsWith('https://'))) return;
			e.preventDefault();
			e.stopPropagation();
			openInBrowser(href);
		}, true);
	}

	function patchAll() {
		document.querySelectorAll('a[target="_blank"]').forEach(patchLink);
	}
	patchAll();

	// MutationObserver：监听 React 动态新增的节点
	var observer = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			mutation.addedNodes.forEach(function(node) {
				if (!node || node.nodeType !== 1) return;
				if (node.tagName === 'A' && node.target === '_blank') patchLink(node);
				if (node.querySelectorAll) node.querySelectorAll('a[target="_blank"]').forEach(patchLink);
			});
		});
	});

	if (document.body) {
		observer.observe(document.body, { childList: true, subtree: true });
	} else {
		document.addEventListener('DOMContentLoaded', function() {
			observer.observe(document.body, { childList: true, subtree: true });
			patchAll();
		});
	}

	// 拦截 window.open（部分链接走编程式弹窗）
	var _origOpen = window.open;
	window.open = function(url, target, features) {
		if (url && typeof url === 'string' &&
			(url.startsWith('http://') || url.startsWith('https://'))) {
			openInBrowser(url);
			return null;
		}
		return _origOpen.apply(this, arguments);
	};

	console.log('[DeepSeek Wrapper] interceptor active, IPC port: %d');
})();`, a.ipcPort, a.ipcPort)
	runtime.WindowExecJS(ctx, js)
}

// OpenInBrowser 用系统默认浏览器打开 URL（供 JS 绑定调用）
func (a *App) OpenInBrowser(url string) {
	log.Printf("Opening in default browser: %s", url)
	runtime.BrowserOpenURL(a.ctx, url)
}

// OnBeforeClose 在窗口关闭前保存状态
func (a *App) OnBeforeClose(ctx context.Context) bool {
	a.saveCurrentWindowState()
	return false // 不阻止关闭
}

// SaveWindowSize 保存当前窗口尺寸 (可通过前端调用)
func (a *App) SaveWindowSize() {
	a.saveCurrentWindowState()
}
